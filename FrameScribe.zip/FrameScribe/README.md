# FrameScribe

Extracts text from local videos (chat screen recordings, YouTube, tutorials) with on-device
ML Kit OCR, removes scroll duplicates, and exports markdown or plain text.

* **Chat transcript mode**: splits `[USER]` / `[AI]` by bubble position.
* **Subtitles and text mode**: crops UI chrome, drops text that stays on screen, writes a clean note.

## Build the APK in the cloud (GitHub Actions)

1. Unzip this project. GitHub's web uploader does not unzip archives.
2. Create an empty repository on github.com (no README, no .gitignore).
3. Push it:

   ```bash
   cd FrameScribe
   git init -b main
   git add .
   git commit -m "Initial commit"
   git remote add origin https://github.com/<you>/<repo>.git
   git push -u origin main
   ```

   Web alternative: repo page -> "uploading an existing file", drag in the unzipped contents
   including the hidden `.github` folder, then commit.
4. Open the repo's **Actions** tab. "Build APK" starts on every push (or press
   **Run workflow**). It takes about 4-8 minutes the first time.
5. Open the finished run, scroll to **Artifacts**, download `FrameScribe-debug-apk` (or
   `-release-apk`), unzip it and install the `.apk` on your phone (allow "install unknown apps").
6. Tagging a release (`git tag v1.0.0 && git push --tags`) also attaches the release APK to a GitHub Release.

### Optional: your own release signing key

Without secrets, the release APK is signed with the debug key (installable, not for Play Store).
To sign properly, add these repository secrets (Settings -> Secrets and variables -> Actions):
`KEYSTORE_BASE64` (`base64 -w0 release.jks`), `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`.

## Local build

Android Studio (Hedgehog or newer) can open the folder directly. From a terminal with Gradle 8.9
and JDK 17: `gradle assembleDebug`.

## Tuning tips

* Chat tags swapped? Settings -> flip "[USER] bubbles are on the right", or use Swap speakers.
* Missing fast subtitles? Lower "Read one frame every".
* Header/footer junk? Raise the top/bottom crop; the preview shows the cropped zones in red.
* Non-Latin scripts: swap the ML Kit dependency in `app/build.gradle.kts` (see the comment there).
