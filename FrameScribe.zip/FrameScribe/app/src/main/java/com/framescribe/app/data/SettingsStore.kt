package com.framescribe.app.data

import android.content.Context
import com.framescribe.app.model.AppSettings

class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    fun load(): AppSettings {
        val d = AppSettings()
        return AppSettings(
            sampleIntervalSec = prefs.getFloat("interval", d.sampleIntervalSec),
            cropTopPct = prefs.getInt("cropTop", d.cropTopPct),
            cropBottomPct = prefs.getInt("cropBottom", d.cropBottomPct),
            cropLeftPct = prefs.getInt("cropLeft", d.cropLeftPct),
            cropRightPct = prefs.getInt("cropRight", d.cropRightPct),
            similarity = prefs.getFloat("similarity", d.similarity),
            userSplitX = prefs.getFloat("splitX", d.userSplitX),
            userOnRight = prefs.getBoolean("userOnRight", d.userOnRight),
            dropPersistent = prefs.getBoolean("dropPersistent", d.dropPersistent)
        )
    }

    fun save(s: AppSettings) {
        prefs.edit()
            .putFloat("interval", s.sampleIntervalSec)
            .putInt("cropTop", s.cropTopPct)
            .putInt("cropBottom", s.cropBottomPct)
            .putInt("cropLeft", s.cropLeftPct)
            .putInt("cropRight", s.cropRightPct)
            .putFloat("similarity", s.similarity)
            .putFloat("splitX", s.userSplitX)
            .putBoolean("userOnRight", s.userOnRight)
            .putBoolean("dropPersistent", s.dropPersistent)
            .apply()
    }
}
