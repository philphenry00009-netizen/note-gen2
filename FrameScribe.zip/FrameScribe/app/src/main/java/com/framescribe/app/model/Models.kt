package com.framescribe.app.model

enum class ProcessingMode(val label: String, val blurb: String) {
    CHAT(
        "Chat transcript",
        "Screen recordings of chats. Splits [USER] and [AI] by bubble position, ready for multi-voice narration."
    ),
    GENERAL(
        "Subtitles and text",
        "YouTube, tutorials, articles. Strips UI chrome and merges scrolling duplicates into one clean note."
    )
}

enum class Speaker(val tag: String) {
    USER("[USER]"),
    AI("[AI]"),
    NOTE("[NOTE]");

    fun next(): Speaker = entries[(ordinal + 1) % entries.size]
}

data class TextBlock(
    val id: Long,
    val speaker: Speaker,
    val text: String,
    val timestampMs: Long
)

data class AppSettings(
    val sampleIntervalSec: Float = 1.5f,
    val cropTopPct: Int = 7,
    val cropBottomPct: Int = 9,
    val cropLeftPct: Int = 0,
    val cropRightPct: Int = 0,
    /** 0.6..0.98 - how alike two lines must be to count as the same line. */
    val similarity: Float = 0.82f,
    /** Chat mode: bubbles whose horizontal centre is right of this fraction are one side. */
    val userSplitX: Float = 0.56f,
    val userOnRight: Boolean = true,
    /** General mode: drop text that is on screen in most frames (titles, channel names, buttons). */
    val dropPersistent: Boolean = true
)
