package com.framescribe.app.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.media.MediaMetadataRetriever
import android.net.Uri
import com.framescribe.app.model.AppSettings
import kotlin.math.abs

/** Pulls frames out of a local video at arbitrary timestamps. */
class FrameSampler(context: Context, uri: Uri) : AutoCloseable {
    private val retriever = MediaMetadataRetriever().apply { setDataSource(context, uri) }

    val durationMs: Long =
        retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L

    fun frameAt(ms: Long): Bitmap? =
        retriever.getFrameAtTime(ms * 1000L, MediaMetadataRetriever.OPTION_CLOSEST)

    override fun close() = retriever.release()
}

object FrameOps {
    private const val SIG = 32

    /** Removes the configured percentage from each edge (status bar, play controls, input box...). */
    fun crop(src: Bitmap, s: AppSettings): Bitmap {
        val x = (src.width * s.cropLeftPct / 100f).toInt()
        val y = (src.height * s.cropTopPct / 100f).toInt()
        val w = src.width - x - (src.width * s.cropRightPct / 100f).toInt()
        val h = src.height - y - (src.height * s.cropBottomPct / 100f).toInt()
        if (w < 16 || h < 16) return src
        if (x == 0 && y == 0 && w == src.width && h == src.height) return src
        return Bitmap.createBitmap(src, x, y, w, h)
    }

    /** Tiny greyscale thumbnail used to skip OCR on frames that did not change at all. */
    fun signature(bmp: Bitmap): IntArray {
        val small = Bitmap.createScaledBitmap(bmp, SIG, SIG, true)
        val px = IntArray(SIG * SIG)
        small.getPixels(px, 0, SIG, 0, 0, SIG, SIG)
        if (small !== bmp) small.recycle()
        return IntArray(px.size) { i ->
            val c = px[i]
            (Color.red(c) * 3 + Color.green(c) * 6 + Color.blue(c)) / 10
        }
    }

    fun difference(a: IntArray, b: IntArray): Double {
        var sum = 0L
        for (i in a.indices) sum += abs(a[i] - b[i])
        return sum.toDouble() / a.size
    }
}
