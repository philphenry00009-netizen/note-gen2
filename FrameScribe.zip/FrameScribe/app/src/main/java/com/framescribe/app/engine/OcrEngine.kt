package com.framescribe.app.engine

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** One ML Kit text block (roughly a paragraph or a chat bubble) with its pixel bounds. */
data class OcrBlock(
    val text: String,
    val lines: List<String>,
    val left: Int,
    val top: Int,
    val right: Int,
    val bottom: Int
)

class OcrEngine : AutoCloseable {
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    suspend fun recognize(bitmap: Bitmap): List<OcrBlock> = suspendCancellableCoroutine { cont ->
        recognizer.process(InputImage.fromBitmap(bitmap, 0))
            .addOnSuccessListener { result ->
                val blocks = result.textBlocks.map { b ->
                    val box = b.boundingBox
                    OcrBlock(
                        text = b.lines.joinToString(" ") { it.text },
                        lines = b.lines.map { it.text },
                        left = box?.left ?: 0,
                        top = box?.top ?: 0,
                        right = box?.right ?: 0,
                        bottom = box?.bottom ?: 0
                    )
                }.sortedBy { it.top }
                cont.resume(blocks)
            }
            .addOnFailureListener { cont.resumeWithException(it) }
    }

    override fun close() = recognizer.close()
}
