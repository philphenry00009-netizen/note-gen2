package com.framescribe.app.ui

import android.app.Application
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.framescribe.app.data.Session
import com.framescribe.app.data.SessionStore
import com.framescribe.app.data.SettingsStore
import com.framescribe.app.engine.Pipeline
import com.framescribe.app.export.Exporter
import com.framescribe.app.model.AppSettings
import com.framescribe.app.model.ProcessingMode
import com.framescribe.app.model.Speaker
import com.framescribe.app.model.TextBlock
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class Screen { HOME, SETTINGS, REVIEW }

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val settingsStore = SettingsStore(app)
    private val sessionStore = SessionStore(app)
    private val pipeline = Pipeline(app)

    private val _screen = MutableStateFlow(Screen.HOME)
    val screen: StateFlow<Screen> = _screen.asStateFlow()

    private val _mode = MutableStateFlow(ProcessingMode.CHAT)
    val mode: StateFlow<ProcessingMode> = _mode.asStateFlow()

    private val _settings = MutableStateFlow(settingsStore.load())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    private val _videoUri = MutableStateFlow<Uri?>(null)
    val videoUri: StateFlow<Uri?> = _videoUri.asStateFlow()

    private val _videoName = MutableStateFlow("")
    val videoName: StateFlow<String> = _videoName.asStateFlow()

    private val _blocks = MutableStateFlow<List<TextBlock>>(emptyList())
    val blocks: StateFlow<List<TextBlock>> = _blocks.asStateFlow()

    private val _processing = MutableStateFlow(false)
    val processing: StateFlow<Boolean> = _processing.asStateFlow()

    private val _progress = MutableStateFlow(0f)
    val progress: StateFlow<Float> = _progress.asStateFlow()

    private val _status = MutableStateFlow("")
    val status: StateFlow<String> = _status.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    private val _hasSession = MutableStateFlow(sessionStore.exists())
    val hasSession: StateFlow<Boolean> = _hasSession.asStateFlow()

    private var job: Job? = null
    private var saveJob: Job? = null

    // ---- navigation / inputs -------------------------------------------------------------

    fun goTo(screen: Screen) { _screen.value = screen }

    fun setMode(mode: ProcessingMode) { _mode.value = mode }

    fun updateSettings(s: AppSettings) {
        _settings.value = s
        settingsStore.save(s)
    }

    fun resetSettings() = updateSettings(AppSettings())

    fun pickVideo(uri: Uri) {
        _videoUri.value = uri
        _videoName.value = queryName(uri) ?: "video"
        _error.value = null
    }

    private fun queryName(uri: Uri): String? =
        getApplication<Application>().contentResolver
            .query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }

    // ---- processing ----------------------------------------------------------------------

    fun startProcessing() {
        val uri = _videoUri.value ?: return
        if (_processing.value) return
        _error.value = null
        _progress.value = 0f
        _processing.value = true
        job = viewModelScope.launch {
            try {
                val result = pipeline.run(uri, _mode.value, _settings.value) { p, msg ->
                    _progress.value = p
                    _status.value = msg
                }
                if (result.isEmpty()) {
                    _error.value = "No text found. Check the crop zones in Settings and try a shorter sample interval."
                } else {
                    _blocks.value = result
                    persist()
                    _screen.value = Screen.REVIEW
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _error.value = e.message ?: "Processing failed."
            } finally {
                _processing.value = false
            }
        }
    }

    fun cancel() { job?.cancel() }

    fun openLastSession() {
        val s = sessionStore.load() ?: return
        _mode.value = s.mode
        _videoName.value = s.title
        _blocks.value = s.blocks
        _screen.value = Screen.REVIEW
    }

    // ---- editing -------------------------------------------------------------------------

    private fun mutate(f: (List<TextBlock>) -> List<TextBlock>) {
        _blocks.update(f)
        persist()
    }

    fun editText(id: Long, text: String) =
        mutate { l -> l.map { if (it.id == id) it.copy(text = text) else it } }

    fun setSpeaker(id: Long, speaker: Speaker) =
        mutate { l -> l.map { if (it.id == id) it.copy(speaker = speaker) else it } }

    fun delete(id: Long) = mutate { l -> l.filter { it.id != id } }

    /** Appends this block's text to the one above it and removes it. */
    fun mergeUp(id: Long) = mutate { l ->
        val i = l.indexOfFirst { it.id == id }
        if (i <= 0) l else merge(l, i - 1, i)
    }

    /** Appends the block below to this one and removes the lower one. */
    fun mergeDown(id: Long) = mutate { l ->
        val i = l.indexOfFirst { it.id == id }
        if (i < 0 || i >= l.lastIndex) l else merge(l, i, i + 1)
    }

    private fun merge(l: List<TextBlock>, keep: Int, drop: Int): List<TextBlock> =
        l.toMutableList().apply {
            val a = this[keep]
            val b = this[drop]
            this[keep] = a.copy(text = a.text.trimEnd() + " " + b.text.trimStart())
            removeAt(drop)
        }

    fun swapSpeakers() = mutate { l ->
        l.map {
            when (it.speaker) {
                Speaker.USER -> it.copy(speaker = Speaker.AI)
                Speaker.AI -> it.copy(speaker = Speaker.USER)
                Speaker.NOTE -> it
            }
        }
    }

    private fun persist() {
        saveJob?.cancel()
        saveJob = viewModelScope.launch(Dispatchers.IO) {
            delay(400)
            sessionStore.save(Session(_mode.value, _videoName.value, _blocks.value))
            _hasSession.value = true
        }
    }

    // ---- export --------------------------------------------------------------------------

    fun fileBase(): String =
        _videoName.value.substringBeforeLast('.').ifBlank { "transcript" }
            .replace(Regex("[^A-Za-z0-9._-]+"), "_") + "_notes"

    fun exportMarkdown(): String =
        Exporter.markdown(_blocks.value, _mode.value, _videoName.value.substringBeforeLast('.'))

    fun exportText(): String = Exporter.plainText(_blocks.value, _mode.value)
}
