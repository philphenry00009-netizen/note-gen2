package com.framescribe.app.export

import com.framescribe.app.model.ProcessingMode
import com.framescribe.app.model.Speaker
import com.framescribe.app.model.TextBlock
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Exporter {
    private val sentenceEnd = Regex("[.!?…:;\"”’)]$")
    private const val MIN_PARAGRAPH = 280

    /** Consecutive blocks from the same speaker become one voiceover turn. */
    private fun turns(blocks: List<TextBlock>): List<Pair<Speaker, List<String>>> {
        val out = mutableListOf<Pair<Speaker, MutableList<String>>>()
        for (b in blocks) {
            val t = b.text.trim()
            if (t.isEmpty()) continue
            val last = out.lastOrNull()
            if (last != null && last.first == b.speaker) last.second.add(t)
            else out.add(b.speaker to mutableListOf(t))
        }
        return out
    }

    /** Joins subtitle-style lines into readable paragraphs (break at a sentence end once long enough). */
    private fun paragraphs(blocks: List<TextBlock>): List<String> {
        val out = mutableListOf<String>()
        val cur = StringBuilder()
        for (b in blocks) {
            val t = b.text.trim()
            if (t.isEmpty()) continue
            if (cur.isNotEmpty()) cur.append(' ')
            cur.append(t)
            if (cur.length >= MIN_PARAGRAPH && sentenceEnd.containsMatchIn(t)) {
                out.add(cur.toString())
                cur.setLength(0)
            }
        }
        if (cur.isNotEmpty()) out.add(cur.toString())
        return out
    }

    fun markdown(blocks: List<TextBlock>, mode: ProcessingMode, title: String): String {
        val date = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val sb = StringBuilder()
        sb.append("# ").append(title.ifBlank { "Extracted notes" }).append("\n\n")
        sb.append("_Mode: ").append(mode.label).append(" | Extracted ").append(date).append("_\n\n")
        if (mode == ProcessingMode.CHAT) {
            turns(blocks).forEach { (sp, parts) ->
                sb.append("**").append(sp.tag).append("** ")
                    .append(parts.joinToString("\n\n")).append("\n\n")
            }
        } else {
            paragraphs(blocks).forEach { sb.append(it).append("\n\n") }
        }
        return sb.toString().trimEnd() + "\n"
    }

    fun plainText(blocks: List<TextBlock>, mode: ProcessingMode): String =
        if (mode == ProcessingMode.CHAT) {
            turns(blocks).joinToString("\n\n") { (sp, parts) -> sp.tag + " " + parts.joinToString("\n") } + "\n"
        } else {
            paragraphs(blocks).joinToString("\n\n") + "\n"
        }

    /** Text of one speaker only, for pasting into a single-voice tool. */
    fun speakerText(blocks: List<TextBlock>, speaker: Speaker): String =
        blocks.filter { it.speaker == speaker }.joinToString("\n\n") { it.text.trim() }

    /** The review screen's raw view: one block per line, tagged in chat mode. */
    fun raw(blocks: List<TextBlock>, mode: ProcessingMode): String =
        blocks.joinToString("\n") { if (mode == ProcessingMode.CHAT) "${it.speaker.tag} ${it.text}" else it.text }
}
