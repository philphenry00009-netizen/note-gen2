package com.framescribe.app.engine

import com.framescribe.app.model.Speaker
import com.framescribe.app.model.TextBlock
import kotlin.math.max
import kotlin.math.min

/** A line or bubble seen in one frame, before it is merged into the transcript. */
class Draft private constructor(
    var speaker: Speaker,
    var text: String,
    var norm: String,
    val ts: Long
) {
    var seen = 1

    companion object {
        fun of(speaker: Speaker, text: String, ts: Long): Draft? {
            val n = TextUtil.normalize(text)
            return if (n.isEmpty()) null else Draft(speaker, text, n, ts)
        }
    }
}

/**
 * Merges the entries of successive frames into one chronological list.
 *
 * Each new frame is matched against the part of the transcript where the previous frame
 * landed. Matched entries are duplicates (and upgrade the stored text if the new copy is
 * more complete). Unmatched entries are inserted next to their matched neighbours, so
 * scrolling down appends at the end and scrolling up prepends in the right place.
 */
class Deduper(private val threshold: Float) {
    private val committed = ArrayList<Draft>()
    private var lastMin = -1
    private var lastMax = -1
    private var frames = 0

    fun add(frame: List<Draft>) {
        if (frame.isEmpty()) return
        frames++

        val lo: Int
        val hi: Int
        if (lastMin >= 0) {
            lo = max(0, lastMin - WINDOW)
            hi = min(committed.size - 1, lastMax + WINDOW)
        } else {
            lo = max(0, committed.size - TAIL)
            hi = committed.size - 1
        }

        val used = HashSet<Int>()
        val match = IntArray(frame.size) { -1 }
        for ((i, e) in frame.withIndex()) {
            var best = -1
            var bestScore = 0.0
            for (j in lo..hi) {
                if (j in used) continue
                val score = TextUtil.matchScore(e.norm, committed[j].norm, threshold.toDouble())
                if (score >= threshold && score > bestScore) {
                    best = j
                    bestScore = score
                }
            }
            if (best >= 0) {
                match[i] = best
                used.add(best)
                val c = committed[best]
                c.seen++
                if (e.norm.length > c.norm.length * 1.05) {
                    c.text = e.text
                    c.norm = e.norm
                }
            }
        }

        // Decide where each unmatched entry goes: after the previous matched entry,
        // otherwise before the next matched one, otherwise at the end.
        val pending = HashMap<Int, MutableList<Draft>>()
        var prev = -1
        for (i in frame.indices) {
            if (match[i] >= 0) {
                prev = match[i]
                continue
            }
            val key = if (prev >= 0) {
                prev + 1
            } else {
                var next = -1
                for (k in i + 1 until frame.size) {
                    if (match[k] >= 0) { next = match[k]; break }
                }
                if (next >= 0) next else committed.size
            }
            pending.getOrPut(key) { mutableListOf() }.add(frame[i])
        }

        val rebuilt = ArrayList<Draft>(committed.size + frame.size)
        val newIndex = HashMap<Int, Int>()
        for (k in 0..committed.size) {
            pending[k]?.let { rebuilt.addAll(it) }
            if (k < committed.size) {
                newIndex[k] = rebuilt.size
                rebuilt.add(committed[k])
            }
        }
        committed.clear()
        committed.addAll(rebuilt)

        val idx = used.mapNotNull { newIndex[it] }
        if (idx.isEmpty()) {
            lastMin = -1
            lastMax = -1
        } else {
            lastMin = idx.min()
            lastMax = idx.max()
        }
    }

    fun result(dropPersistent: Boolean): List<TextBlock> {
        var list: List<Draft> = committed
        if (dropPersistent && frames >= MIN_FRAMES_FOR_CHROME) {
            val persistent = committed.filter { it.seen >= frames * 0.7 }.toSet()
            if (persistent.isNotEmpty() && persistent.size <= committed.size / 2) {
                list = committed.filter { it !in persistent }
            }
        }
        return list.mapIndexed { i, d -> TextBlock(i.toLong(), d.speaker, d.text, d.ts) }
    }

    private companion object {
        const val WINDOW = 40
        const val TAIL = 80
        const val MIN_FRAMES_FOR_CHROME = 6
    }
}
