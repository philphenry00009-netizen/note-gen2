@file:OptIn(ExperimentalMaterial3Api::class)

package com.framescribe.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.framescribe.app.model.AppSettings
import kotlin.math.roundToInt

@Composable
fun SettingsScreen(vm: MainViewModel) {
    val s by vm.settings.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = { TextButton(onClick = { vm.goTo(Screen.HOME) }) { Text("Back") } }
            )
        }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("Sampling", style = MaterialTheme.typography.titleMedium)
            LabeledSlider("Read one frame every", s.sampleIntervalSec, 0.5f..5f, 8, { "%.1f s".format(it) }) {
                vm.updateSettings(s.copy(sampleIntervalSec = it))
            }
            Text(
                "Shorter catches fast subtitles and quick scrolling but takes longer.",
                style = MaterialTheme.typography.bodySmall
            )

            HorizontalDivider(Modifier.padding(vertical = 8.dp))
            Text("Crop zones (ignored by OCR)", style = MaterialTheme.typography.titleMedium)
            CropPreview(s)
            PctSlider("Top", s.cropTopPct) { vm.updateSettings(s.copy(cropTopPct = it)) }
            PctSlider("Bottom", s.cropBottomPct) { vm.updateSettings(s.copy(cropBottomPct = it)) }
            PctSlider("Left", s.cropLeftPct) { vm.updateSettings(s.copy(cropLeftPct = it)) }
            PctSlider("Right", s.cropRightPct) { vm.updateSettings(s.copy(cropRightPct = it)) }

            HorizontalDivider(Modifier.padding(vertical = 8.dp))
            Text("Duplicate detection", style = MaterialTheme.typography.titleMedium)
            LabeledSlider("Treat lines as the same above", s.similarity, 0.6f..0.98f, 0, { "${(it * 100).roundToInt()}%" }) {
                vm.updateSettings(s.copy(similarity = it))
            }
            SwitchRow("Remove text that stays on screen (subtitles mode)", s.dropPersistent) {
                vm.updateSettings(s.copy(dropPersistent = it))
            }

            HorizontalDivider(Modifier.padding(vertical = 8.dp))
            Text("Chat mode: who said it", style = MaterialTheme.typography.titleMedium)
            LabeledSlider("Left/right split line", s.userSplitX, 0.4f..0.7f, 0, { "${(it * 100).roundToInt()}%" }) {
                vm.updateSettings(s.copy(userSplitX = it))
            }
            SwitchRow("[USER] bubbles are on the right", s.userOnRight) {
                vm.updateSettings(s.copy(userOnRight = it))
            }
            Text(
                "A bubble whose centre is right of the dashed line counts as the right-hand speaker. " +
                    "If tags come out swapped, flip the switch or use Swap speakers on the review screen.",
                style = MaterialTheme.typography.bodySmall
            )

            OutlinedButton(
                onClick = { vm.resetSettings() },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp)
            ) { Text("Reset to defaults") }
        }
    }
}

@Composable
private fun CropPreview(s: AppSettings) {
    val shade = Color(0x66E53935)
    val line = MaterialTheme.colorScheme.primary
    val outline = MaterialTheme.colorScheme.outline
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
        Canvas(
            Modifier
                .height(240.dp)
                .aspectRatio(9f / 16f)
                .border(1.dp, outline)
        ) {
            val w = size.width
            val h = size.height
            drawRect(shade, Offset(0f, 0f), Size(w, h * s.cropTopPct / 100f))
            drawRect(shade, Offset(0f, h * (1 - s.cropBottomPct / 100f)), Size(w, h * s.cropBottomPct / 100f))
            drawRect(shade, Offset(0f, 0f), Size(w * s.cropLeftPct / 100f, h))
            drawRect(shade, Offset(w * (1 - s.cropRightPct / 100f), 0f), Size(w * s.cropRightPct / 100f, h))
            val x = w * s.userSplitX
            drawLine(line, Offset(x, 0f), Offset(x, h), strokeWidth = 2f)
        }
    }
}

@Composable
private fun PctSlider(label: String, value: Int, onChange: (Int) -> Unit) {
    LabeledSlider(label, value.toFloat(), 0f..40f, 39, { "${it.roundToInt()}%" }) { onChange(it.roundToInt()) }
}

@Composable
private fun LabeledSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    steps: Int,
    format: (Float) -> String,
    onChange: (Float) -> Unit
) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label)
            Text(format(value), color = MaterialTheme.colorScheme.primary)
        }
        Slider(value = value, onValueChange = onChange, valueRange = range, steps = steps)
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, Modifier.weight(1f).padding(end = 12.dp))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
