@file:OptIn(ExperimentalMaterial3Api::class)

package com.framescribe.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.framescribe.app.model.ProcessingMode

@Composable
fun HomeScreen(vm: MainViewModel) {
    val mode by vm.mode.collectAsStateWithLifecycle()
    val uri by vm.videoUri.collectAsStateWithLifecycle()
    val name by vm.videoName.collectAsStateWithLifecycle()
    val processing by vm.processing.collectAsStateWithLifecycle()
    val progress by vm.progress.collectAsStateWithLifecycle()
    val status by vm.status.collectAsStateWithLifecycle()
    val error by vm.error.collectAsStateWithLifecycle()
    val hasSession by vm.hasSession.collectAsStateWithLifecycle()

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { picked ->
        if (picked != null) vm.pickVideo(picked)
    }

    // Keep the screen awake while frames are being read; the work stops if the app is killed.
    val view = LocalView.current
    DisposableEffect(processing) {
        view.keepScreenOn = processing
        onDispose { view.keepScreenOn = false }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("FrameScribe") },
                actions = { TextButton(onClick = { vm.goTo(Screen.SETTINGS) }) { Text("Settings") } }
            )
        }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("What are you extracting?", style = MaterialTheme.typography.titleMedium)
            ProcessingMode.entries.forEach { m ->
                ModeCard(m, selected = m == mode, enabled = !processing) { vm.setMode(m) }
            }

            Text("Which video?", style = MaterialTheme.typography.titleMedium)
            OutlinedButton(
                onClick = { picker.launch(arrayOf("video/*")) },
                enabled = !processing,
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (uri == null) "Choose a video (MP4)" else name) }

            Button(
                onClick = { vm.startProcessing() },
                enabled = uri != null && !processing,
                modifier = Modifier.fillMaxWidth()
            ) { Text("Extract text") }

            if (processing) {
                LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
                Text(status, style = MaterialTheme.typography.bodyMedium)
                OutlinedButton(onClick = { vm.cancel() }, modifier = Modifier.fillMaxWidth()) { Text("Cancel") }
            }

            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }

            if (hasSession && !processing) {
                TextButton(onClick = { vm.openLastSession() }) { Text("Open last session") }
            }
        }
    }
}

@Composable
private fun ModeCard(mode: ProcessingMode, selected: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val container = if (selected) MaterialTheme.colorScheme.secondaryContainer
    else MaterialTheme.colorScheme.surfaceVariant
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = enabled, onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = container)
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            RadioButton(selected = selected, onClick = null)
            Column(Modifier.padding(start = 12.dp)) {
                Text(mode.label, style = MaterialTheme.typography.titleSmall)
                Text(mode.blurb, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
