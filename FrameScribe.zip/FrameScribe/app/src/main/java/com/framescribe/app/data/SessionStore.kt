package com.framescribe.app.data

import android.content.Context
import com.framescribe.app.model.ProcessingMode
import com.framescribe.app.model.Speaker
import com.framescribe.app.model.TextBlock
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class Session(val mode: ProcessingMode, val title: String, val blocks: List<TextBlock>)

/** Keeps the last extraction on disk so edits survive the app being closed. */
class SessionStore(context: Context) {
    private val file = File(context.filesDir, "last_session.json")

    fun exists(): Boolean = file.exists()

    fun save(session: Session) {
        val arr = JSONArray()
        session.blocks.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id)
                    .put("sp", it.speaker.name)
                    .put("text", it.text)
                    .put("ts", it.timestampMs)
            )
        }
        val root = JSONObject()
            .put("mode", session.mode.name)
            .put("title", session.title)
            .put("blocks", arr)
        file.writeText(root.toString())
    }

    fun load(): Session? = runCatching {
        val root = JSONObject(file.readText())
        val arr = root.getJSONArray("blocks")
        Session(
            ProcessingMode.valueOf(root.getString("mode")),
            root.getString("title"),
            List(arr.length()) { i ->
                val b = arr.getJSONObject(i)
                TextBlock(b.getLong("id"), Speaker.valueOf(b.getString("sp")), b.getString("text"), b.getLong("ts"))
            }
        )
    }.getOrNull()
}
