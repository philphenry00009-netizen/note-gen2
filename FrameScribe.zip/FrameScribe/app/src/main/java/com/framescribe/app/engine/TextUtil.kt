package com.framescribe.app.engine

import kotlin.math.abs

object TextUtil {
    private val whitespace = Regex("\\s+")
    private val nonWord = Regex("[^\\p{L}\\p{N} ]")
    private val clock =
        Regex("^\\d{1,2}:\\d{2}(:\\d{2})?(\\s?[AaPp][Mm])?(\\s*/\\s*\\d{1,2}:\\d{2}(:\\d{2})?)?$")
    private const val MIN_PARTIAL = 12

    fun clean(s: String): String = s.replace(whitespace, " ").trim()

    fun normalize(s: String): String =
        s.lowercase().replace(nonWord, " ").replace(whitespace, " ").trim()

    /** Clock stamps, video progress ("1:23 / 10:00"), single glyphs and other OCR junk. */
    fun isNoise(s: String): Boolean {
        val t = s.trim()
        return t.count { it.isLetterOrDigit() } < 2 || clock.matches(t)
    }

    fun levenshtein(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost)
            }
            val t = prev; prev = cur; cur = t
        }
        return prev[b.length]
    }

    /**
     * Similarity in 0..1 (1 = identical). Returns 0.0 early when cheap bounds prove it
     * cannot reach [threshold]: edit distance is >= length gap and >= half the
     * character-histogram distance. That keeps scrolling videos fast.
     */
    private fun sim(a: String, b: String, threshold: Double): Double {
        val mx = maxOf(a.length, b.length)
        if (mx == 0) return 1.0
        if (minOf(a.length, b.length).toDouble() / mx < threshold) return 0.0
        val h = IntArray(128)
        for (c in a) h[c.code and 127]++
        for (c in b) h[c.code and 127]--
        var l1 = 0
        for (x in h) l1 += abs(x)
        if (1.0 - l1 / (2.0 * mx) < threshold) return 0.0
        return 1.0 - levenshtein(a, b).toDouble() / mx
    }

    /**
     * Score for "is this the same line as that one?" on normalised strings.
     * Handles lines cut off at the screen edge: a shorter text that equals the start or the
     * end of a longer one counts as a match.
     */
    fun matchScore(a: String, b: String, threshold: Double): Double {
        if (a.isEmpty() || b.isEmpty()) return 0.0
        if (a == b) return 1.0
        val (s, l) = if (a.length <= b.length) a to b else b to a
        if (s.length >= MIN_PARTIAL && l.contains(s)) return 1.0
        var best = sim(a, b, threshold)
        if (s.length >= MIN_PARTIAL) {
            best = maxOf(best, sim(s, l.take(s.length), threshold), sim(s, l.takeLast(s.length), threshold))
        }
        return best
    }
}
