package com.framescribe.app.engine

import com.framescribe.app.model.AppSettings
import com.framescribe.app.model.Speaker

/** Mode A: every OCR block is a bubble; its horizontal position decides who said it. */
object ChatProcessor {
    fun toDrafts(blocks: List<OcrBlock>, frameWidth: Int, ts: Long, s: AppSettings): List<Draft> =
        blocks.mapNotNull { b ->
            val text = TextUtil.clean(b.text)
            if (TextUtil.isNoise(text)) return@mapNotNull null
            val centre = (b.left + b.right) / 2f / frameWidth
            val onRight = centre >= s.userSplitX
            val speaker = if (onRight == s.userOnRight) Speaker.USER else Speaker.AI
            Draft.of(speaker, text, ts)
        }
}

/** Mode B: line-by-line text with no speakers; chrome is mostly removed by cropping. */
object GeneralProcessor {
    fun toDrafts(blocks: List<OcrBlock>, ts: Long): List<Draft> =
        blocks.flatMap { it.lines }.mapNotNull { raw ->
            val text = TextUtil.clean(raw)
            if (TextUtil.isNoise(text)) null else Draft.of(Speaker.NOTE, text, ts)
        }
}
