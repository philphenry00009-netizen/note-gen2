@file:OptIn(ExperimentalMaterial3Api::class)

package com.framescribe.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.framescribe.app.export.Exporter
import com.framescribe.app.model.ProcessingMode
import com.framescribe.app.model.Speaker
import com.framescribe.app.model.TextBlock

@Composable
fun ReviewScreen(vm: MainViewModel) {
    val blocks by vm.blocks.collectAsStateWithLifecycle()
    val mode by vm.mode.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    val isChat = mode == ProcessingMode.CHAT

    var rawView by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }

    val saveMd = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/markdown")) { uri ->
        if (uri != null) writeUri(ctx, uri, vm.exportMarkdown())
    }
    val saveTxt = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) writeUri(ctx, uri, vm.exportText())
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Review (${blocks.size})") },
                navigationIcon = { TextButton(onClick = { vm.goTo(Screen.HOME) }) { Text("Back") } },
                actions = {
                    Box {
                        TextButton(onClick = { menuOpen = true }) { Text("Export") }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            DropdownMenuItem(text = { Text("Save as .md") }, onClick = {
                                menuOpen = false
                                saveMd.launch(vm.fileBase() + ".md")
                            })
                            DropdownMenuItem(text = { Text("Save as .txt") }, onClick = {
                                menuOpen = false
                                saveTxt.launch(vm.fileBase() + ".txt")
                            })
                            DropdownMenuItem(text = { Text("Copy all (markdown)") }, onClick = {
                                menuOpen = false
                                copyToClipboard(ctx, vm.exportMarkdown())
                            })
                        }
                    }
                }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad)) {
            Row(
                Modifier
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(selected = !rawView, onClick = { rawView = false }, label = { Text("Blocks") })
                FilterChip(selected = rawView, onClick = { rawView = true }, label = { Text("Raw text") })
                if (isChat) {
                    AssistChip(onClick = { vm.swapSpeakers() }, label = { Text("Swap speakers") })
                    AssistChip(
                        onClick = { copyToClipboard(ctx, Exporter.speakerText(blocks, Speaker.USER)) },
                        label = { Text("Copy [USER]") }
                    )
                    AssistChip(
                        onClick = { copyToClipboard(ctx, Exporter.speakerText(blocks, Speaker.AI)) },
                        label = { Text("Copy [AI]") }
                    )
                }
            }

            if (rawView) {
                Column(
                    Modifier
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp)
                ) {
                    SelectionContainer { Text(Exporter.raw(blocks, mode)) }
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(blocks, key = { it.id }) { block ->
                        BlockCard(
                            block = block,
                            showSpeaker = isChat,
                            onEdit = { vm.editText(block.id, it) },
                            onSpeaker = { vm.setSpeaker(block.id, it) },
                            onCopy = { copyToClipboard(ctx, block.text) },
                            onMergeUp = { vm.mergeUp(block.id) },
                            onMergeDown = { vm.mergeDown(block.id) },
                            onDelete = { vm.delete(block.id) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun BlockCard(
    block: TextBlock,
    showSpeaker: Boolean,
    onEdit: (String) -> Unit,
    onSpeaker: (Speaker) -> Unit,
    onCopy: () -> Unit,
    onMergeUp: () -> Unit,
    onMergeDown: () -> Unit,
    onDelete: () -> Unit
) {
    // Local copy keeps the cursor stable while typing; it resets when the stored text changes
    // from outside (for example after a merge).
    var text by remember(block.text) { mutableStateOf(block.text) }
    val compact = PaddingValues(horizontal = 8.dp)

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (showSpeaker) {
                    AssistChip(
                        onClick = { onSpeaker(block.speaker.next()) },
                        label = { Text(block.speaker.tag) }
                    )
                }
                Text(formatTime(block.timestampMs), style = MaterialTheme.typography.labelMedium)
            }
            OutlinedTextField(
                value = text,
                onValueChange = {
                    text = it
                    onEdit(it)
                },
                modifier = Modifier.fillMaxWidth()
            )
            Row {
                TextButton(onClick = onCopy, contentPadding = compact) { Text("Copy") }
                TextButton(onClick = onMergeUp, contentPadding = compact) { Text("Merge up") }
                TextButton(onClick = onMergeDown, contentPadding = compact) { Text("Merge down") }
                TextButton(onClick = onDelete, contentPadding = compact) { Text("Delete") }
            }
        }
    }
}

private fun formatTime(ms: Long): String {
    val total = ms / 1000
    return "%d:%02d".format(total / 60, total % 60)
}

private fun copyToClipboard(ctx: Context, text: String) {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("FrameScribe", text))
    Toast.makeText(ctx, "Copied", Toast.LENGTH_SHORT).show()
}

private fun writeUri(ctx: Context, uri: Uri, text: String) {
    runCatching {
        ctx.contentResolver.openOutputStream(uri, "wt")?.bufferedWriter()?.use { it.write(text) }
    }.onSuccess {
        Toast.makeText(ctx, "Saved", Toast.LENGTH_SHORT).show()
    }.onFailure {
        Toast.makeText(ctx, "Save failed: ${it.message}", Toast.LENGTH_LONG).show()
    }
}
