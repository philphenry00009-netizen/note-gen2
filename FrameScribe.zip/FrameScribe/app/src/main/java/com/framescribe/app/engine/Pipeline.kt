package com.framescribe.app.engine

import android.content.Context
import android.net.Uri
import com.framescribe.app.model.AppSettings
import com.framescribe.app.model.ProcessingMode
import com.framescribe.app.model.TextBlock
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext

class Pipeline(private val context: Context) {

    suspend fun run(
        uri: Uri,
        mode: ProcessingMode,
        s: AppSettings,
        onProgress: (Float, String) -> Unit
    ): List<TextBlock> = withContext(Dispatchers.Default) {
        val dedup = Deduper(s.similarity)
        OcrEngine().use { ocr ->
            FrameSampler(context, uri).use { sampler ->
                val duration = sampler.durationMs
                require(duration > 0) { "Could not read this video. Try an MP4 (H.264)." }

                val step = (s.sampleIntervalSec * 1000).toLong().coerceAtLeast(250L)
                val total = duration / step + 1
                var t = 0L
                var index = 0L
                var lastSig: IntArray? = null

                while (t <= duration) {
                    ensureActive()
                    val frame = sampler.frameAt(t)
                    if (frame != null) {
                        val cropped = FrameOps.crop(frame, s)
                        val sig = FrameOps.signature(cropped)
                        val prev = lastSig
                        if (prev == null || FrameOps.difference(prev, sig) > SKIP_DIFF) {
                            val blocks = ocr.recognize(cropped)
                            val drafts = when (mode) {
                                ProcessingMode.CHAT -> ChatProcessor.toDrafts(blocks, cropped.width, t, s)
                                ProcessingMode.GENERAL -> GeneralProcessor.toDrafts(blocks, t)
                            }
                            dedup.add(drafts)
                            lastSig = sig
                        }
                        if (cropped !== frame) cropped.recycle()
                        frame.recycle()
                    }
                    index++
                    onProgress(
                        (index.toFloat() / total).coerceIn(0f, 1f),
                        "Frame $index of $total"
                    )
                    t += step
                }
            }
        }
        dedup.result(dropPersistent = mode == ProcessingMode.GENERAL && s.dropPersistent)
    }

    private companion object {
        /** Mean grey-level change below this means the screen is identical; skip OCR. */
        const val SKIP_DIFF = 0.3
    }
}
